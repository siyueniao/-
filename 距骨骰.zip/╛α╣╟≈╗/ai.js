var x=0,x1=0,x2=0,x3=0
var sum1,sum2
var num1=9,num2=9

function nextStep(ownBoard,otherBoard,figure){
    var sum11=0  //我方总分
    var sum22=0  //对方总分
    for(i=0;i<3;i++){
        sum11+=ownBoard[i*3+0];
        if (ownBoard[i*3+1]!=ownBoard[i*3]){
            if (ownBoard[i*3+2]!=ownBoard[i*3]&&ownBoard[i*3+2]!=ownBoard[i*3+1])
                sum11+=ownBoard[i*3+2];
            else
            sum11+=ownBoard[i*3+2]*3;
            sum11+=ownBoard[i*3+1];
        }
        else{
            if (ownBoard[i*3+2]==ownBoard[i*3])
                sum11+=ownBoard[i*3+2]*5
            else
                sum11+=ownBoard[i*3+2]
            sum11+=ownBoard[i*3]*3
        }
    }
    for(i=0;i<3;i++){
        sum22+=otherBoard[i*3+0];
        if (otherBoard[i*3+1]!=otherBoard[i*3]){
            if (otherBoard[i*3+2]!=otherBoard[i*3]&&otherBoard[i*3+2]!=otherBoard[i*3+1])
                sum22+=otherBoard[i*3+2];
            else
                sum22+=otherBoard[i*3+2]*3;
            sum22+=otherBoard[i*3+1];
        }
        else{
            if (otherBoard[i*3+2]==otherBoard[i*3])
                sum22+=otherBoard[i*3+2]*5;
            else
                sum22+=otherBoard[i*3+2];
            sum22+=otherBoard[i*3]*3
        }
    }
        
    var num=0
    var difference=[]
    for(i=0;i<3;i++){
        if (ownBoard[i]==figure)
        num+=1
    }
    difference[1]=(num*2+1)*figure
    num=0
    for(i=3;i<6;i++){
        if (ownBoard[i]==figure)
        num+=1
    }
    difference[2]=(num*2+1)*figure
    num=0
    for(i=6;i<9;i++){
        if (ownBoard[i]==figure)
        num+=1
    }
    difference[3]=(num*2+1)*figure
    
    num=0
    for(i=0;i<3;i++)
        if (otherBoard[i]==figure)
            num+=1
    difference[1]+=(num*num)*figure
    num=0
    for(i=3;i<6;i++)
        if (otherBoard[i]==figure)
            num+=1
    difference[2]+=(num*num)*figure
    num=0
    for(i=6;i<9;i++)
        if (otherBoard[i]==figure)
            num+=1
    difference[3]+=(num*num)*figure
        
    if (ownBoard[0]!=0&&ownBoard[1]!=0&&ownBoard[2]!=0)
        difference[1]=0
    if (ownBoard[3]!=0&&ownBoard[4]!=0&&ownBoard[5]!=0)
        difference[2]=0
    if (ownBoard[6]!=0&&ownBoard[7]!=0&&ownBoard[8]!=0)
        difference[3]=0
    
    var diff1
    var diff2
    var diff3 //记录哪一行“得分”最高
    if (difference[1]>=difference[2]&&difference[2]>=difference[3]){
        diff1=1
        diff2=2
        diff3=3
    }
    if (difference[1]>=difference[3]&&difference[3]>=difference[3]){
        diff1=1
        diff2=3
        diff3=2
    }
    if (difference[2]>=difference[1]&&difference[1]>=difference[3]){
        diff1=2
        diff2=1
        diff3=3
    }
    if (difference[2]>=difference[3]&&difference[3]>=difference[1]){
        diff1=2
        diff2=3
        diff3=1
    }
    if (difference[3]>=difference[1]&&difference[1]>=difference[2]){
        diff1=3
        diff2=1
        diff3=2
    }
    if (difference[3]>=difference[2]&&difference[2]>=difference[1]){
        diff1=3
        diff2=2
        diff3=1
    }
    var othernum=0  //记录目前对面空格数
    for(i=0;i<9;i++)
        if (otherBoard[i]!=0)
            othernum+=1
    
    var filled=[]
    filled[1]=3;
    filled[2]=3;
    filled[3]=3;  //记录第几行还有几个空位
    choice=[-1,-1,-1,-1]   //判断第n行是否还有空位
    if (ownBoard[0]==0){
        choice[1]=0;
        filled[1]--;
    }
    if (ownBoard[1]==0){
        choice[1]=1;
        filled[1]--;
    }
    if (ownBoard[2]==0){
        choice[1]=2;
        filled[1]--;
    }
    if (ownBoard[3]==0){
        choice[2]=3;
        filled[2]--;
    }
    if (ownBoard[4]==0){
        choice[2]=4;
        filled[2]--;
    }
    if (ownBoard[5]==0){
        choice[2]=5;
        filled[2]--;
    }
    if (ownBoard[6]==0){
        choice[3]=6;
        filled[3]--;
    }
    if (ownBoard[7]==0){
        choice[3]=7;
        filled[3]--;
    }
    if (ownBoard[8]==0){
        choice[3]=8;
        filled[3]--;
    }
    if(filled[2]<filled[1]){
        if(filled[3]<filled[2])
        filled[0]=3;
        else filled[0]=2;
    }
    else{
        if(filled[3]<filled[1])
        filled[0]=3;
        else filled[0]=1;
    }
    
    if (othernum==8&&sum11+difference[diff1]<sum22+4){
        if (otherBoard[diff1*3]==figure||otherBoard[diff1*3+1]==figure||otherBoard[diff1*3+2]==figure)
            return choice[diff1]
        if (otherBoard[diff2*3]==figure||otherBoard[diff2*3+1]==figure||otherBoard[diff2*3+2]==figure)
            return choice[diff2]
        if (otherBoard[diff3*3]==figure||otherBoard[diff3*3+1]==figure||otherBoard[diff3*3+2]==figure)
            return choice[diff3]
    }

    if(difference[diff1]-difference[diff2]<4&&filled[diff1]>filled[diff2]){
        if(difference[diff2]-difference[diff3]<4&&filled[diff2]>filled[diff3])
        return choice[diff3];
        return choice[diff2];
    }
    if(difference[diff1]==difference[diff2]&&difference[diff1]==difference[diff3])
    return choice[filled[0]]

    return choice[diff1]
}
function sum_1(){
    sum1=0;
    for(i=0;i<3;i++)
    {
        sum1+=array1[i*3+0];
        if(array1[i*3+1]!=array1[i*3+0])
        {
            if(array1[i*3+2]!=array1[i*3+0]&&array1[i*3+2]!=array1[i*3+1])
            sum1+=array1[i*3+2];
            else sum1+=array1[i*3+2]*3;
            sum1+=array1[i*3+1];
        }
        else
        {
            if(array1[i*3+2]==array1[i*3+0])
            sum1+=array1[i*3+2]*5;
            else sum1+=array1[i*3+2];
            sum1+=array1[i*3+0]*3;
        }
    }
}
function sum_2(){
    sum2=0;
    for(i=0;i<3;i++)
    {
        sum2+=array2[i*3+0];
        if(array2[i*3+1]!=array2[i*3+0])
        {
            if(array2[i*3+2]!=array2[i*3+0]&&array2[i*3+2]!=array2[i*3+1])
            sum2+=array2[i*3+2];
            else sum2+=array2[i*3+2]*3;
            sum2+=array2[i*3+1];
        }
        else
        {
            if(array2[i*3+2]==array2[i*3+0])
            sum2+=array2[i*3+2]*5;
            else sum2+=array2[i*3+2];
            sum2+=array2[i*3+0]*3;
        }
    }
}
function startgame(){
    if(x==0) shake1();
    else shake2();
}
function shake1(){
    if(x==0)
    {
        x3=Math.floor((Math.random()*6)+1);
        switch(x3){
        case 1:document.getElementById("t1").src="img/1.gif";break;
        case 2:document.getElementById("t1").src="img/2.gif";break;
        case 3:document.getElementById("t1").src="img/3.gif";break;
        case 4:document.getElementById("t1").src="img/4.gif";break;
        case 5:document.getElementById("t1").src="img/5.gif";break;
        default:document.getElementById("t1").src="img/6.gif";
        }
    }
    setTimeout(function(){x1=x3;},1500);
}
function shake2(){
    if(x==1)
    {
        x2=Math.floor((Math.random()*6)+1);
        switch(x2){
        case 1:document.getElementById("t2").src="img/11.gif";break;
        case 2:document.getElementById("t2").src="img/22.gif";break;
        case 3:document.getElementById("t2").src="img/33.gif";break;
        case 4:document.getElementById("t2").src="img/44.gif";break;
        case 5:document.getElementById("t2").src="img/55.gif";break;
        default:document.getElementById("t2").src="img/66.gif";
        }
    }
    var m=nextStep(array2,array1,x2);
    if(m==0)  setTimeout(()=>{long("long1")},1500);
    if(m==1)  setTimeout(()=>{long("long2")},1500);
    if(m==2)  setTimeout(()=>{long("long3")},1500);
    if(m==3)  setTimeout(()=>{long("long4")},1500);
    if(m==4)  setTimeout(()=>{long("long5")},1500);
    if(m==5)  setTimeout(()=>{long("long6")},1500);
    if(m==6)  setTimeout(()=>{long("long7")},1500);
    if(m==7)  setTimeout(()=>{long("long8")},1500);
    if(m==8)  setTimeout(()=>{long("long9")},1500);
}
function pic(x){
    switch(x){
    case 1:return "img/1.png";break;
    case 2:return "img/2.png";break;
    case 3:return "img/3.png";break;
    case 4:return "img/4.png";break;
    case 5:return "img/5.png";break;
    default:return "img/6.png";
    }
}
function hu(id){
    if(x1!=0&&array1[(Math.floor((id[2]-0+2)/3)-1)*3+(id[2]-0+2)%3]==0)
    {
        num1--;
        document.getElementById(id).src=pic(x1);
        switch (id){
        case "hu1":array1[0]=x1;break;
        case "hu2":array1[1]=x1;break;
        case "hu3":array1[2]=x1;break;
        case "hu4":array1[3]=x1;break;
        case "hu5":array1[4]=x1;break;
        case "hu6":array1[5]=x1;break;
        case "hu7":array1[6]=x1;break;
        case "hu8":array1[7]=x1;break;
        default:array1[8]=x1;break;
        }
        if(id=="hu1"||id=="hu2"||id=="hu3")
        {
            if(array2[0]==x1)
            {
                array2[0]=0;
                document.getElementById("long1").src="img/out1.png";
                num2++;
            }
            if(array2[1]==x1)
            {
                array2[1]=0;
                document.getElementById("long2").src="img/out1.png";
                num2++;
            }
            if(array2[2]==x1)
            {
                array2[2]=0;
                document.getElementById("long3").src="img/out1.png";
                num2++;
            }
        }
        else if(id=="hu4"||id=="hu5"||id=="hu6")
        {
            if(array2[3]==x1)
            {
                array2[3]=0;
                document.getElementById("long4").src="img/out3.png";
                num2++;
            }
            if(array2[4]==x1)
            {
                array2[4]=0;
                document.getElementById("long5").src="img/out3.png";
                num2++;
            }
            if(array2[5]==x1)
            {
                array2[5]=0;
                document.getElementById("long6").src="img/out3.png";
                num2++;
            }
        }
        else
        {
            if(array2[6]==x1)
            {
                array2[6]=0;
                document.getElementById("long7").src="img/out1.png";
                num2++;
            }
            if(array2[7]==x1)
            {
                array2[7]=0;
                document.getElementById("long8").src="img/out1.png";
                num2++;
            }
            if(array2[8]==x1)
            {
                array2[8]=0;
                document.getElementById("long9").src="img/out1.png";
                num2++;
            }
        }
        x1=0;
        x2=0;
        x=1;
        if(num1!=0)
        shake2();
        sum_1();
        sum_2();
        document.getElementById("sum11").innerHTML="玩家A总分为："+sum1;
        document.getElementById("sum22").innerHTML="玩家B总分为："+sum2;
        if(num1==0||num2==0)
        setTimeout(()=>{over()},500);
    }
}
function long(id){
    if(x2!=0&&array2[(Math.floor((id[4]-0+2)/3)-1)*3+(id[4]-0+2)%3]==0)
    {
        num2--;
        document.getElementById(id).src=pic(x2);
        switch (id){
        case "long1":array2[0]=x2;break;
        case "long2":array2[1]=x2;break;
        case "long3":array2[2]=x2;break;
        case "long4":array2[3]=x2;break;
        case "long5":array2[4]=x2;break;
        case "long6":array2[5]=x2;break;
        case "long7":array2[6]=x2;break;
        case "long8":array2[7]=x2;break;
        default:array2[8]=x2;break;
        }
        if(id=="long1"||id=="long2"||id=="long3")
        {
            if(array1[0]==x2)
            {
                array1[0]=0;
                document.getElementById("hu1").src="img/out2.png";
                num1++;
            }
            if(array1[1]==x2)
            {
                array1[1]=0;
                document.getElementById("hu2").src="img/out2.png";
                num1++;
            }
            if(array1[2]==x2)
            {
                array1[2]=0;
                document.getElementById("hu3").src="img/out2.png";
                num1++;
            }
        }
        else if(id=="long4"||id=="long5"||id=="long6")
        {
            if(array1[3]==x2)
            {
                array1[3]=0;
                document.getElementById("hu4").src="img/out4.png";
                num1++;
            }
            if(array1[4]==x2)
            {
                array1[4]=0;
                document.getElementById("hu5").src="img/out4.png";
                num1++;
            }
            if(array1[5]==x2)
            {
                array1[5]=0;
                document.getElementById("hu6").src="img/out4.png";
                num1++;
            }
        }
        else
        {
            if(array1[6]==x2)
            {
                array1[6]=0;
                document.getElementById("hu7").src="img/out2.png";
                num1++;
            }
            if(array1[7]==x2)
            {
                array1[7]=0;
                document.getElementById("hu8").src="img/out2.png";
                num1++;
            }
            if(array1[8]==x2)
            {
                array1[8]=0;
                document.getElementById("hu9").src="img/out2.png";
                num1++;
            }
        }
        x1=0;
        x2=0;
        x=0;
        if(num2!=0)
        shake1();
        sum_1();
        sum_2();
        document.getElementById("sum11").innerHTML="玩家A总分为："+sum1;
        document.getElementById("sum22").innerHTML="玩家B总分为："+sum2;
        if(num1==0||num2==0)
        setTimeout(()=>{over()},500)
    }
}
function over()
{
    if(sum1>sum2)
    alert(sum1+":"+sum2+"   "+"玩家A胜利！");
    else if(sum1<sum2)
    alert(sum1+":"+sum2+"   "+"玩家B胜利！");
    else alert(sum1+":"+sum2+"   "+"平局");
    location.href="初始.html"
}
var array1=[]
var array2=[]
for(i=0;i<9;i++)
array1[i]=0;
for(i=0;i<9;i++)
array2[i]=0;