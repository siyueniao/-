def nextStep(ownBoard,otherBoard,figure):
    sum1=0  #我方总分
    sum2=0  #对方总分
    i=0
    while i<3:
        sum1+=ownBoard[i*3+0]
        if ownBoard[i*3+1]!=ownBoard[i*3]:
            if (ownBoard[i*3+2]!=ownBoard[i*3])and(ownBoard[i*3+2]!=ownBoard[i*3+1]):
                sum1+=ownBoard[i*3+2]
            else:
                sum1+=ownBoard[i*3+2]*3
            sum1+=ownBoard[i*3+1]
        else:
            if ownBoard[i*3+2]==ownBoard[i*3]:
                sum1+=ownBoard[i*3+2]*5
            else:
                sum1+=ownBoard[i*3+2]
            sum1+=ownBoard[i*3]*3
        i+=1
    i=0
    while i<3:
        sum2+=otherBoard[i*3+0]
        if otherBoard[i*3+1]!=otherBoard[i*3]:
            if (otherBoard[i*3+2]!=otherBoard[i*3])and(otherBoard[i*3+2]!=otherBoard[i*3+1]):
                sum2+=otherBoard[i*3+2]
            else:
                sum2+=otherBoard[i*3+2]*3
            sum2+=otherBoard[i*3+1]
        else:
            if otherBoard[i*3+2]==otherBoard[i*3]:
                sum2+=otherBoard[i*3+2]*5
            else:
                sum2+=otherBoard[i*3+2]
            sum2+=otherBoard[i*3]*3
        i+=1
        
    num=0
    i=0
    difference=[]
    while i<3:
        if ownBoard[i]==figure:
            num+=1
        i+=1
    difference[1]=(num*2+1)*figure
    num=0
    while i<6:
        if ownBoard[i]==figure:
            num+=1
        i+=1
    difference[2]=(num*2+1)*figure
    num=0
    while i<9:
        if ownBoard[i]==figure:
            num+=1
        i+=1
    difference[3]=(num*2+1)*figure
    
    num=0
    i=0
    while i<3:
        if otherBoard[i]==figure:
            num+=1
        i+=1
    difference[1]+=(num*num)*figure
    num=0
    while i<6:
        if otherBoard[i]==figure:
            num+=1
        i+=1
    difference[2]+=(num*num)*figure
    num=0
    while i<9:
        if otherBoard[i]==figure:
            num+=1
        i+=1
    difference[3]+=(num*num)*figure
        
    if (ownBoard[0]!=0)and(ownBoard[1]!=0)and(ownBoard[2]!=0):
        difference[1]=0
    if (ownBoard[3]!=0)and(ownBoard[4]!=0)and(ownBoard[5]!=0):
        difference[2]=0
    if (ownBoard[6]!=0)and(ownBoard[7]!=0)and(ownBoard[8]!=0):
        difference[3]=0
    
    
    if (difference[1]>=difference[2])and(difference[2]>=difference[3]):
        diff1=1  #记录哪一行“得分”最高
        diff2=2
        diff3=3
    if (difference[1]>=difference[3])and(difference[3]>=difference[2]):
        diff1=1  #记录哪一行“得分”最高
        diff2=3
        diff3=2
    if (difference[2]>=difference[1])and(difference[1]>=difference[3]):
        diff1=2  #记录哪一行“得分”最高
        diff2=1
        diff3=3
    if (difference[2]>=difference[3])and(difference[3]>=difference[1]):
        diff1=2  #记录哪一行“得分”最高
        diff2=3
        diff3=1
    if (difference[3]>=difference[1])and(difference[1]>=difference[2]):
        diff1=3  #记录哪一行“得分”最高
        diff2=1
        diff3=2
    if (difference[3]>=difference[2])and(difference[2]>=difference[1]):
        diff1=3  #记录哪一行“得分”最高
        diff2=2
        diff3=1
    
    i=0
    othernum=0  #记录目前对面已用格数
    while i<9:
        if otherBoard[i]!=0:
            othernum+=1
        i+=1
    
    filled=[]
    filled[1]=3
    filled[2]=3
    filled[3]=3  #记录第几行还有几个空位
    choice=[-1,-1,-1,-1]   #判断第n行是否还有空位
    if (ownBoard[0]==0):
        choice[1]=0
        filled[1]-=1
    if (ownBoard[1]==0):
        choice[1]=1
        filled[1]-=1
    if (ownBoard[2]==0):
        choice[1]=2
        filled[1]
    if (ownBoard[3]==0):
        choice[2]=3
        filled[2]-=1
    if (ownBoard[4]==0):
        choice[2]=4
        filled[2]-=1
    if (ownBoard[5]==0):
        choice[2]=5
        filled[2]-=1
    if (ownBoard[6]==0):
        choice[3]=6
        filled[3]-=1
    if (ownBoard[7]==0):
        choice[3]=7
        filled[3]-=1
    if (ownBoard[8]==0):
        choice[3]=8
        filled[3]-=1
    if(filled[2]<filled[1]):
        if(filled[3]<filled[2]):
            filled[0]=3
        else:
            filled[0]=2
    else:
        if(filled[3]<filled[1]):
            filled[0]=3
        else:
            filled[0]=1
    
    if (othernum==8)and(sum1+difference[diff1]+3<sum2):
        if (otherBoard[diff1*3]==figure)or(otherBoard[diff1*3+1]==figure)or(otherBoard[diff1*3+2]==figure):
            return choice[diff1]
        if (otherBoard[diff2*3]==figure)or(otherBoard[diff2*3+1]==figure)or(otherBoard[diff2*3+2]==figure):
            return choice[diff2]
        if (otherBoard[diff3*3]==figure)or(otherBoard[diff3*3+1]==figure)or(otherBoard[diff3*3+2]==figure):
            return choice[diff3]
    
    if(difference[diff1]-difference[diff2]<4)and(filled[diff1]>filled[diff2]):
        if(difference[diff2]-difference[diff3]<4)and(filled[diff2]>filled[diff3]):
            return choice[diff3]
        return choice[diff2]
    if(difference[diff1]==difference[diff2])and(difference[diff1]==difference[diff3]):
        return choice[filled[0]]

    return choice[diff1]
            
                
    
        
        
        
    


ownBoard=[3,3,0,4,5,6,1,0,3]
otherBoard=[0,6,6,3,1,2,3,4,0]
figure=4
i=nextStep(ownBoard,otherBoard,figure)
print(i)